

from django.shortcuts import render,redirect
from django.http import HttpResponse
from members.models import Member
from members.models import array
import numpy as np
import json
import joblib

from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score
from .forms import CustomerForm


from django.core.files.storage import default_storage
import pandas as pd
import json


from sklearn.metrics import accuracy_score, precision_score

from sklearn.model_selection import train_test_split
from .models import ModelMetadata

# files import 
from .helpers import evaluate_model

class linear_reg():
    def __init__(self):
        print("in constructor ")


    # Function to calculate m and b
    def linear_regression(self,X, y):
        x_mean = np.mean(X)
        y_mean = np.mean(y)
        numerator = np.sum((X - x_mean) * (y - y_mean))
        denominator = np.sum((X - x_mean) ** 2)
        m = numerator / denominator
        b = y_mean - (m * x_mean)
        return m, b

    # Function to calculate prediction
    def predict(self,X, m, b):
        return m * X + b
    
    # Function to calculate RMSE
    def rmse(self,y_true, y_pred):
        return np.sqrt(np.mean((y_true - y_pred) ** 2))

        
    

def members(request):

    #member = Member(firstname='Emil', lastname='Refsnes')
    #member  = array(integer_array1=[7, 8, 10, 12, 15, 18],integer_array2=[9, 10, 12, 13, 16, 20])
    #member  = array(integer_array1=[1,2,3,4,5,6,7,8,9,10])

    #member.save()
    
    #print(array.objects.all().values())

    ar= array.objects.get(id=5)

    # Extract JSON strings from the model
    integer_array1_json = ar.integer_array1
    integer_array2_json = ar.integer_array2

    # Deserialize JSON strings to Python lists
    integer_array1_list = json.loads(integer_array1_json)
    integer_array2_list = json.loads(integer_array2_json)

    # Convert Python lists to NumPy arrays
    x = np.array(integer_array1_list)
    y = np.array(integer_array2_list)

    # Print or use the NumPy arrays
    print("x:", x)
    print("y:", y)

    # Training the model
    LR = linear_reg()
    m, b = LR.linear_regression(x,y)
    # Making predictions
    predictions = LR.predict(x, m, b)
    # Calculating RMSE
    error = LR.rmse(y, predictions)

    print("Slope (m):", m)
    print("Intercept (b):", b)
    print("Predictions:", predictions)
    print("RMSE:", error)





    return HttpResponse("Hello world!")

def index(request):
    form = CustomerForm()
    context = {'form': form}


    return render(request,'index.html',context)


def main(request):
    print("in main ! ")
    return render(request,'index.html')

def data_load(request):
    if request.method == 'POST' and request.FILES.get('csv_file'):
        csv_file = request.FILES['csv_file']
        df = pd.read_csv(csv_file)
        print("in data_load")
        print(df.head(2))
        # Process the data
        df = df.dropna()
        df = df.drop_duplicates()

        # Split the data
        if 'target' in df.columns:
            X = df.drop('target', axis=1)
            y = df['target']
        else:
            X = df.iloc[:, :-1]
            y = df.iloc[:, -1]

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Store the data in session
        request.session['X_train'] = X_train.to_json(orient='split')
        request.session['X_test'] = X_test.to_json(orient='split')
        request.session['y_train'] = y_train.to_json(orient='split')
        request.session['y_test'] = y_test.to_json(orient='split')
        #print(y_train.head())
        return render(request, 'index.html',{'uploaded':True})

    return render(request, 'index.html')

def problem_type(request):
    if request.method == 'POST':
        problem_type = request.POST.get('problem_type')
        print("in problem_type route")
        if problem_type == 'classification':
            return redirect('classification')
        
        elif problem_type == 'regression':
            return redirect('regression')
        
def classification(request):
    print("in classification route")
    
    #X_train = pd.read_json(request.session.get('X_train'), orient='split')
    # y_train = pd.read_json(request.session.get('y_train'), orient='split')
    # print(y_train.head())
    # print("y value : ")
    #print((request.session.get('y_train')).head(2))

    #print(y_train.head())
    return render(request, 'index.html',{'classific':True})

def regression(request):
    print("in regression problem")

    return render(request,'index.html',{'regress':True})

def Decision_tree_classifier(request):
    print("in decision tree")

    # Load training data
    X_train = pd.read_json(request.session.get('X_train'), orient='split')
    y_train_json = request.session.get('y_train')
    y_train_data = json.loads(y_train_json)

    # Extract data and convert to DataFrame
    y_train = pd.DataFrame(
        data=y_train_data['data'],
        index=y_train_data['index'],
        columns=[y_train_data['name']]
    ).values.ravel()  # Convert DataFrame to 1D array

    # Train Decision Tree Classifier
    clf = DecisionTreeClassifier()
    clf.fit(X_train, y_train)

    # Save the model to a file
    model_filename = 'decision_tree_model.pkl'
    joblib.dump(clf, model_filename)

    # Store the filename in session
    request.session['model_file_name'] = model_filename

    # Redirect to evaluation function
    return redirect('evaluate_model')


def random_forest_classifier(request):
    print("in random forest classification")
    return render(request,'index.html')

def logistic_regression_classifier(request):
    print("in logistic regression classification")
    return render(request,'index.html')

def SVM_classifier(request):
    print("in SVM classification")
    return render(request,'index.html')

def Linear_Regressor(request):
    print("in linear regression")
    return render(request,'index.html')

def SVM_regressor(request):
    print("in SVM regression")
    return render(request,'index.html')