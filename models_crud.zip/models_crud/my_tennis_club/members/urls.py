from django.urls import path
from . import views

urlpatterns = [
    path('', views.main, name='main'),
    path('data_load/', views.data_load, name='data_load'),
    path('problem_type/', views.problem_type, name='problem_type'),
    path('classification/', views.classification, name='classification'),
    path('regression/', views.regression, name='regression'),
    path('decision_tree_classifier/', views.Decision_tree_classifier, name='decision_tree_classifier'),
    path('random_forest_classifier/', views.random_forest_classifier, name='random_forest_classifier'),
    path('logistic_regression_classifier/', views.logistic_regression_classifier, name='logistic_regression_classifier'),
    path('svm_classifier/', views.SVM_classifier, name='svm_classifier'),
    path('linear_regressor/', views.Linear_Regressor, name='linear_regressor'),
    path('svm_regressor/', views.SVM_regressor, name='svm_regressor'),
    path('evaluate_model/',views.evaluate_model,name = 'evaluate_model'),
    path('index/', views.index, name='index'),
    path('members/', views.members, name='members'),
]
