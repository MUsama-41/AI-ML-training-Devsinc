import joblib
from django.shortcuts import render, redirect
from .models import ModelMetadata
from sklearn.metrics import accuracy_score, precision_score
import pandas as pd
import json


def evaluate_model(request):
    print("Evaluating the model")

    # Get model metadata ID from session
    model_metadata_name = request.session.get('model_file_name')
    if not model_metadata_name:
        return redirect('index')  # Redirect if model metadata ID is not available

    # Retrieve model metadata from the database
    # model_metadata = ModelMetadata.objects.get(model_name=model_metadata_name)

    # # Access the path of the model file
    # model_filename = model_metadata.model_file.path

    # Load the model from the file
    clf = joblib.load(model_metadata_name)
    print("model loaded")
    # Load test data
    X_test = pd.read_json(request.session.get('X_test'), orient='split')
    y_test_json = request.session.get('y_test')
    y_test_data = json.loads(y_test_json)

    y_test = pd.DataFrame(
        data=y_test_data['data'],
        index=y_test_data['index'],
        columns=[y_test_data['name']]
    ).values.ravel()  # Convert DataFrame to 1D array

    # Make predictions
    y_pred = clf.predict(X_test)

    # Calculate accuracy and precision
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')  # Use weighted average for multi-class

    # Pass metrics to the template
    context = {
        'accuracy': accuracy,
        'precision': precision
    }
    print("at end of evaluate")
    return render(request, 'results.html', context)
